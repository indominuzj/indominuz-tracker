GitHub Pages ready bundle

Repo name is preconfigured as: indominuz-tracker

How to publish:
1. Create a GitHub repo named `indominuz-tracker`
2. Upload all files from this zip to the repo root
3. In GitHub go to Settings > Pages
4. Under Build and deployment:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
5. Wait for Pages to publish
6. Open:
   https://<your-github-username>.github.io/indominuz-tracker/

Install on Android:
- Open the site in Chrome
- Tap the Install button, or use browser menu > Add to Home screen

Important:
- This bundle assumes the repo name stays `indominuz-tracker`
- If you change the repo name, update:
  - manifest.json start_url
  - manifest.json scope
  - icon paths
  - service worker paths
  - the manifest link and service worker register path in index.html
