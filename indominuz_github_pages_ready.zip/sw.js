const CACHE_NAME = 'indominuz-gh-pages-v1';
const ASSETS = [
  '/indominuz-tracker/',
  '/indominuz-tracker/index.html',
  '/indominuz-tracker/manifest.json',
  '/indominuz-tracker/icon-192.png',
  '/indominuz-tracker/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(resp => resp || fetch(event.request))
  );
});
